#ifndef __SDRAM_H__
#define __SDRAM_H__

#include "main.h"

#define EXT_SDRAM_TEST_OK			0
#define EXT_SDRAM_TEST_ERR		1

#define SDRAM_BANK1_ADDR      ((uint32_t)0xC0000000)	// 8MBytes
#define SDRAM_BANK2_ADDR      ((uint32_t)0xC0800000)	// 8MBytes
#define SDRAM_BANK3_ADDR      ((uint32_t)0xC1000000)	// 8MBytes
#define SDRAM_BANK4_ADDR      ((uint32_t)0xC0800000)	// 8MBytes

#define SDRAM_WORD_NUM				(16 * 1024 * 1024)		// 16Mword, each word 16 bit
#define SDRAM_BYTE_NUM				(32 * 1024 * 1024)		// totally 0x02000000 bytes

void SDRAM_Initialization_Sequence(SDRAM_HandleTypeDef *hsdram);
uint8_t extSDRAM_test(void);

#endif	/* __SDRAM_H__ */
